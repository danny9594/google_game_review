1. 토픽 모델링하기
2. 워드 임베딩하기
4. 유사한 리뷰 찾아서 던지기
9. 머신러닝 해보기
4조_게임_머신러닝
!! file 경로, ram 용량 https://bskyvision.com/799

good_model.h5
LSTM 정확도 82%

LSTM_DL
LSTM 관련 코드, 첨부자료

자카드 유사도
자카드유사도.ipynb(폐기?)

코사인 유사도
코사인유사도.zip

라우트_html연결.zip

word2vec.zip